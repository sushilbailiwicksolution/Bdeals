<?php
class Employee_model extends CI_Model{


	public function __construct(){
		parent::__construct();
	}

	public function getEmployees(){
		$this->db->select('id, name, email, country, contact_no, add_date, status');
		$employeeList = $this->db->get_where(TBL_PREFIX.TBL_EMPLOYEE);
		log_message('debug', 'Last query to get employee list ['.$this->db->last_query().']');
		if( !$employeeList ){
			return null;
		}else{
			$dataToReturn = $employeeList->result_array();
			return $dataToReturn;
		}

	}

	public function getEmployeeDetailsById( $empId ){
		$this->db->select('name, email');
		$employeeData = $this->db->get_where(TBL_PREFIX.TBL_EMPLOYEE, array('id'=>$empId));
		if( !$employeeData ){
			return null;
		}else{
			return $employeeData->result_array();
		}
	}

	public function addEmployee(){
		$name     = $this->input->post('name');
		$email    = $this->input->post('email');
		$password = $this->input->post('password');
		$country  = $this->input->post('country');
		$contact  = $this->input->post('contact');
		$add_date = $this->input->post('add_date');

		$resp = $this->createEmployeeIdPassword($email, $password);
		if( strcmp($resp['status'], 'duplicate') == 0 || strcmp($resp['status'], 'false') == 0 ){
			return $resp['status'];
		}else{

			$employeeData = array('id'=>$resp['id'], 'name'=>$name, 'contact_no'=>$contact, 'email'=>$email, 'country'=>$country, 'add_date'=>$add_date);

			$result = $this->db->insert(TBL_PREFIX.TBL_EMPLOYEE, $employeeData);
			/*if ( !$result && $this->db->error()['code'] == 1062 ){
				return "duplicate";
			}else{*/
				if ( $this->db->affected_rows() > 0 ){
					return "true";
				}else{
					return "false";
				}
			/*}*/
		}
	}

	public function createEmployeeIdPassword( $email, $password ){
		$userEmpData = array('user_id'=>$email, 'password'=>$password, 'type'=>'employee');
		$result = $this->db->insert(TBL_PREFIX.TBL_USERS, $userEmpData);
		if( !$result && $this->db->error()['code'] == 1062 ){
			return array('status'=>'duplicate', 'id'=>-1);
		}else{
			if ( $this->db->affected_rows() > 0 ){
				return array('status'=>'true', 'id'=>$this->db->insert_id());
			}else{
				return array('status'=>'false', 'id'=>-1);
			}
		}
	}
}
?>
