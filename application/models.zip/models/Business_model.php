<?php
class Business_model extends CI_Model{


	public function __construct(){
		parent::__construct();
	}

	public function getBusinessDetailsByFormId( $businessType, $form_id ){
		log_message('debug', 'In getBusinessDetailsByFormId() function=============================');
		$this->db->select('*');
		if( strcasecmp( $businessType, 'sell_business' ) == 0 ){
			$this->db->from(TBL_PREFIX.TBL_BUSINESS_DETAILS);
			$this->db->join(TBL_PREFIX.TBL_SELL_BUSINESS_DETAILS, TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_id = '.TBL_PREFIX.TBL_SELL_BUSINESS_DETAILS.'.form_id');
		}else if( strcasecmp( $businessType, 'joint_ventures' ) == 0 ){
			$this->db->from(TBL_PREFIX.TBL_BUSINESS_DETAILS);
			$this->db->join(TBL_PREFIX.TBL_JV_BUSINESS_DETAILS, TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_id = '.TBL_PREFIX.TBL_JV_BUSINESS_DETAILS.'.form_id');
		}else if( strcasecmp( $businessType, 'buy_business' ) == 0 ){
			$this->db->from(TBL_PREFIX.TBL_BUSINESS_DETAILS);
			$this->db->join(TBL_PREFIX.TBL_BUY_BUSINESS_DETAILS, TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_id = '.TBL_PREFIX.TBL_BUY_BUSINESS_DETAILS.'.form_id');
		}else if( strcasecmp( $businessType, 'startup_business' ) == 0 ){
			$this->db->from(TBL_PREFIX.TBL_BUSINESS_DETAILS);
			$this->db->join(TBL_PREFIX.TBL_STARTUP_BUSINESS_DETAILS, TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_id ='.TBL_PREFIX.TBL_STARTUP_BUSINESS_DETAILS.'.form_id');
		}		
		$this->db->where(TBL_PREFIX.TBL_BUSINESS_DETAILS.'.FORM_ID', $form_id);
		$userBusinessData = $this->db->get();
		log_message('debug', 'Last Query ['.$this->db->last_query().']');
		if( !$userBusinessData ){
			return null;
		}else{
			$dataToReturn = $userBusinessData->result_array();
			return $dataToReturn;
		}

	}

	public function getBusinessOfCustomer(){
		$this->db->select('form_id, key_headline, contact, business_type, status');
		$businessList = $this->db->get_where(TBL_PREFIX.TBL_BUSINESS_DETAILS, array('customer_id'=>$this->session->userdata('userid')));
		log_message('debug','Last query ['.$this->db->last_query().']');
		if ( !$businessList ){
			return null;
		}else{
			return $businessList->result();
		}
	}
}
?>
