<?php
class Listing_details_model extends CI_Model{


	public function __construct(){
		parent::__construct();
	}
	
	
	public function getFeaturedListing(){
		
		/*select t1.form_id,key_headline,description,industry_preference,ask_price from bd_business_details t1
left join bd_sell_business_details t5 on t1.form_id=t5.form_id
left join bd_buy_business_details t3 on t1.form_id=t3.form_id
where form_type='Featured' order by t1.form_id ASC*/
		
		/*$fetListing="select t1.form_id,key_headline,description,listing_category,ask_price from bd_business_details t1
left join bd_sell_business_details t5 on t1.form_id=t5.form_id
where form_type='Featured' and business_type='sell_a_business' order by t1.form_id DESC limit 4";*/
		
		
		$this->db->select('*');
		$this->db->from(TBL_PREFIX.TBL_BUSINESS_DETAILS);
		$this->db->join(TBL_PREFIX.TBL_SELL_BUSINESS_DETAILS, TBL_PREFIX.TBL_SELL_BUSINESS_DETAILS.'.form_id = '.TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_id','left');
		//$this->db->join(TBL_PREFIX.TBL_BUY_BUSINESS_DETAILS, TBL_PREFIX.TBL_BUY_BUSINESS_DETAILS.'.form_id = '.TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_id','left');
		$this->db->where(TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_type', 'Featured');
		$this->db->where(TBL_PREFIX.TBL_BUSINESS_DETAILS.'.business_type', 'sell_a_business');
		$this->db->order_by(TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_id', "DESC");
		$Featured = $this->db->get();
		log_message('debug', 'User_model: getFeaturedListing: ['.$this->db->last_query().']');
		
		if( !$Featured ){
			return null;
		}else{
			return $Featured->result_array();
		}
	}


	
	
	
	
	public function getBusinessDetails(){
		
		$frm_id         = $this->input->post('frm_id');
		$business_type  = $this->input->post('business_type');
		

		log_message('debug', 'Form_id ['.$frm_id.']');
		log_message('debug', 'Business_type ['.$business_type.']');


		$this->db->select('*');
		$this->db->from(TBL_PREFIX.TBL_BUSINESS_DETAILS);
		
		if($business_type=="buy_a_business"){
			$this->db->join(TBL_PREFIX.TBL_BUY_BUSINESS_DETAILS,TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_id = '.TBL_PREFIX.TBL_BUY_BUSINESS_DETAILS.'.form_id');
		}	
		if($business_type=="sell_a_business"){
			$this->db->join(TBL_PREFIX.TBL_SELL_BUSINESS_DETAILS,TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_id = '.TBL_PREFIX.TBL_SELL_BUSINESS_DETAILS.'.form_id');
		}
		if($business_type=="joint_venture"){
			$this->db->join(TBL_PREFIX.TBL_JV_BUSINESS_DETAILS,TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_id = '.TBL_PREFIX.TBL_JV_BUSINESS_DETAILS.'.form_id');
		}
		if($business_type=="start_up"){
			$this->db->join(TBL_PREFIX.TBL_SU_BUSINESS_DETAILS,TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_id = '.TBL_PREFIX.TBL_SU_BUSINESS_DETAILS.'.form_id');
		}
		if($business_type=="real_estate"){
			$this->db->join(TBL_PREFIX.TBL_RE_BUSINESS_DETAILS,TBL_PREFIX.TBL_BUSINESS_DETAILS.'.form_id = '.TBL_PREFIX.TBL_RE_BUSINESS_DETAILS.'.form_id');
		}
		$this->db->where(TBL_PREFIX.TBL_BUSINESS_DETAILS.'.FORM_ID',$frm_id);
		$userBusinessData = $this->db->get();
		log_message('debug', 'Last Query ['.$this->db->last_query().']');
		
		if( !$userBusinessData ){
			
			return null;
		}else{
			return $userBusinessData->result_array();
		}
		
		
		
	}
	
	public function getBusinessImageDocuments(){
		
		$frm_id = $this->input->post('frm_id');
		$business_type   = $this->input->get('business_type');
		
		log_message('debug', 'Form_id ['.$frm_id.']');
		log_message('debug', 'Business_type ['.$business_type.']');
		
		$this->db->select('*');
		$this->db->from(TBL_PREFIX.TBL_BUSINESS_DOCUMENTS);
		
		
		$this->db->where(TBL_PREFIX.TBL_BUSINESS_DOCUMENTS.'.FORM_ID',$frm_id);
		$userBusinessDocuments = $this->db->get();
		log_message('debug', 'Last Query ['.$this->db->last_query().']');
		
		if( !$userBusinessDocuments ){
			
			return null;
		}else{
			return $userBusinessDocuments->result_array();
		}
		
		
		
	}
	
	public function getAdditionalDetails(){
		
		$frm_id = $this->input->post('frm_id');
		$business_type   = $this->input->get('business_type');
		
		log_message('debug', 'Form_id ['.$frm_id.']');
		log_message('debug', 'Business_type ['.$business_type.']');
		
		$this->db->select('*');
		$this->db->from(TBL_PREFIX.TBL_ADDITIONAL_DETAILS);
		
		
		$this->db->where(TBL_PREFIX.TBL_ADDITIONAL_DETAILS.'.FORM_ID',$frm_id);
		$additionalDetails = $this->db->get();
		log_message('debug', 'Last Query ['.$this->db->last_query().']');
		
		if( !$additionalDetails ){
			
			return null;
		}else{
			return $additionalDetails->result_array();
		}
	}

	
	public function getAdditionalFinancialDetails(){
		
		$frm_id = $this->input->post('frm_id');
		$business_type   = $this->input->get('business_type');
		
		log_message('debug', 'Form_id ['.$frm_id.']');
		log_message('debug', 'Business_type ['.$business_type.']');
		
		$this->db->select('*');
		$this->db->from(TBL_PREFIX.TBL_ADDITIONAL_FINANCIAL_DETAILS);
		
		
		$this->db->where(TBL_PREFIX.TBL_ADDITIONAL_FINANCIAL_DETAILS.'.FORM_ID',$frm_id);
		$additionalFinancialDetails = $this->db->get();
		log_message('debug', 'Last Query ['.$this->db->last_query().']');
		
		if( !$additionalFinancialDetails ){
			
			return null;
		}else{
			return $additionalFinancialDetails->result_array();
		}
	}
	
	
	

	public function getContactFromUserDetails(){
		
		//$frm_id = $this->input->post('frm_id');
		//$business_type   = $this->input->get('business_type');
		
		//log_message('debug', 'Form_id ['.$frm_id.']');
		//log_message('debug', 'Business_type ['.$business_type.']');
		
		if( $this->session->userdata('is_logged_in') != null && $this->session->userdata('is_logged_in') === true ){
			$customer_id = 	$this->session->userdata('userid');
			$this->db->select('*');
			$this->db->from(TBL_PREFIX.TBL_CUSTOMER_DETAILS);
		
		
			$this->db->where(TBL_PREFIX.TBL_CUSTOMER_DETAILS.'.CUSTOMER_ID',$customer_id);
			$contactFromUserDetails = $this->db->get();
			log_message('debug', 'Last Query ['.$this->db->last_query().']');
		
			if( !$contactFromUserDetails ){
			
				return null;
			}else{
				return $contactFromUserDetails->result_array();
			}
		
		}else{
			return null;
		}
		
	}

	
}	
?>	