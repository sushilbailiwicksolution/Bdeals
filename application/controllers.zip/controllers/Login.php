<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {


	function __construct(){
		parent::__construct();
	}

	public function index(){
		$this->load->model('user_model', 'user');
		if( $this->user->validateCustomer() ){
			//Code to show view of user after login
			redirect('home');
		}else{
			redirect('home');
		}
	}

	public function logout(){
		log_message('debug', 'In LOGOUT');
		$this->session->sess_destroy();
		redirect('home');
	}

}
