<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Assign extends CI_Controller {

	function __construct(){
		parent::__construct();
		//check_isvalidated();
	}

	public function index($bType, $assignedTo, $formId)
	{
		$this->load->library('parser');
		$this->load->helper('html');
		$header['title']  = 'Business Deals';
		$header[ 'css_name' ] = array( 'admin/css/jquery.dataTables.min', 'admin/css/entypo', 'admin/css/font-awesome.min', 'admin/css/bootstrap.min', 'admin/css/mouldifi-forms', 'admin/css/mouldifi-core' ) ;
		//$header[ 'js_name' ]  = array( 'jquery' );
		//$header[ 'showLeftPanel' ] = true;
		$footer['fjs_name'] = array( 'admin/js/jquery.min', 'admin/js/jquery.dataTables.min', 'admin/js/bootstrap.min', 'admin/js/bootstrap/validator.min', 'admin/js/plugins/metismenu/jquery.metisMenu', 'admin/js/plugins/blockui-master/jquery-ui', 'admin/js/plugins/blockui-master/jquery.blockUI', 'admin/js/plugins/flot/jquery.flot.min', 'admin/js/plugins/flot/jquery.flot.tooltip.min', 'admin/js/plugins/flot/jquery.flot.resize.min', 'admin/js/plugins/flot/jquery.flot.selection.min', 'admin/js/plugins/flot/jquery.flot.pie.min', 'admin/js/plugins/flot/jquery.flot.time.min', 'admin/js/scripts/functions', 'admin/js/plugins/chartjs/Chart.min' );

		$this->load->model('admin/Employee_model', 'employee');
		$data['employees'] = $this->employee->getEmployeeList( $bType );
		$data['assignedTo'] = $assignedTo;
		$data['formId'] = $formId;

		$this->load->view('admin/include/header', $header );
		$this->load->view('admin/expl_assign', $data);
		$this->parser->parse('admin/include/footer', $footer );
	}


	public function assignCase(){
		$this->load->library('parser');
		$this->load->helper('html');

		$this->load->model('admin/Employee_model', 'employee');
		$empDetails = $this->employee->getEmployeeDetailsById( $this->input->post('assigned_to') );

		$this->load->model('admin/Assign_model', 'assign');
		$res = $this->assign->assignCaseToUser();
		if( strcasecmp( $res, "true" ) == 0 ){
			//Send mail code
			if( $this->emailmethods->sendMail( 'gaurav@bailiwicksolution.com', 'Business Deals', $empDetails->email, NULL, NULL, 'Business Deals:: Notification!', 'Dear '.$empDetails->name.' You have a new business case.') ){
				log_message('info', 'Email sent to '.$empDetails->email.' address');
			}else{
				log_message('info', 'Email not send to '.$empDetails->email.' address');
			}
			$this->session->set_flashdata('msg', 'Case assigned successfully.');
			redirect(base_url().'admin/seller');
		}else{
			if( strcasecmp( $res, "false" ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! some thing went wrong please try again.');
				log_message('debug', 'Unable to assign case to ['.$this->input->post('assigned_to').']. Due to db insertion fail');
			}else if( strcasecmp( $res, "duplicate" ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! same case already assigned to ['.$this->input->post('assigned_to').'].');
				log_message('debug', 'Unable to assign case to ['.$this->input->post('assigned_to').']. Due to duplicate case to same user');
			}
			redirect(base_url().'admin/seller');
		}
	}
	
		public function assignCaseUser(){
			
		 	 $user_id=$this->uri->segment('4');
		
		//die;
		$this->load->library('parser');
		$this->load->helper('html');

		$this->load->model('admin/Employee_model', 'employee');
		$empDetails = $this->employee->getEmployeeDetailsById( $this->input->post('assigned_to') );

		$this->load->model('admin/Assign_model', 'assign');
		$res = $this->assign->assignQueryToEmployee();
		if( strcasecmp( $res, "true" ) == 0 ){
			//Send mail code
			if( $this->emailmethods->sendMail( 'gaurav@bailiwicksolution.com', 'Business Deals', $empDetails->email, NULL, NULL, 'Business Deals:: Notification!', 'Dear '.$empDetails->name.' You have a new business case.') ){
				log_message('info', 'Email sent to '.$empDetails->email.' address');
			}else{
				log_message('info', 'Email not send to '.$empDetails->email.' address');
			}
			$this->session->set_flashdata('msg', 'Query assigned successfully.');
			redirect(base_url().'admin/singleuserquery/'.$user_id);
		}else{
			if( strcasecmp( $res, "false" ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! some thing went wrong please try again.');
				log_message('debug', 'Unable to assign case to ['.$this->input->post('assigned_to').']. Due to db insertion fail');
			}else if( strcasecmp( $res, "duplicate" ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! same case already assigned to ['.$this->input->post('assigned_to').'].');
				log_message('debug', 'Unable to assign Query to ['.$this->input->post('assigned_to').']. Due to duplicate case to same user');
			}
			redirect(base_url().'admin/singleuserquery/'.$user_id);
		}
	}


	public function assignUser(){
		$this->load->model('admin/Assign_model', 'assign');
		$res = $this->assign->assignCustomerToEmployee();
		if( strcasecmp( $res, 'true' ) == 0 ){
			$this->load->model('admin/Users_model', 'users');
			if( strcasecmp( $this->users->updateUserStatus( $this->input->post('user_id') ), 'true' ) == 0 ){
				$this->session->set_flashdata('msg', 'User assigned successfully.');
			}else{
				$this->session->set_flashdata('msg', 'User assignment failed.');
			}
		}else{
			if( strcasecmp( $res, 'false' ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! some thing went wrong please try again.');
				log_message('debug', 'Unable to assign user to ['.$this->input->post('assigned_to').']. Due to db insertion fail');
			}else if( strcasecmp( $res, 'duplicate' ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! same user already assigned to ['.$this->input->post('assigned_to').'].');
				log_message('debug', 'Unable to assign user to ['.$this->input->post('assigned_to').']. Due to duplicate user to same employee');
			}else if( strcasecmp( $res, 'already_assigned' ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! same user already assigned to ['.$this->input->post('assigned_to').'].');
				log_message('debug', 'Unable to assign user to ['.$this->input->post('assigned_to').']. Due to duplicate user to same employee');
			}
		}
		//redirect(base_url().'admin/newusers');
		redirect(base_url().'admin/'.$this->input->post('to'));
	}

	public function assignQuery(){
		$this->load->model('admin/Assign_model', 'assign');
		$res = $this->assign->assignQueryToEmployee();
		if( strcasecmp( $res, 'true' ) == 0 ){
			$this->load->model('admin/Users_model', 'users');
			if( strcasecmp( $this->users->updateQueryStatus( $this->input->post('query_id') ), 'true' ) == 0 ){
				$this->session->set_flashdata('msg', 'Query assigned successfully.');
			}else{
				$this->session->set_flashdata('msg', 'Query assignment failed.');
			}
		}else{
			if( strcasecmp( $res, 'false' ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! some thing went wrong please try again.');
				log_message('debug', 'Unable to assign query to ['.$this->input->post('assigned_to').']. Due to db insertion fail');
			}else if( strcasecmp( $res, 'duplicate' ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! same query already assigned to ['.$this->input->post('assigned_to').'].');
				log_message('debug', 'Unable to assign query to ['.$this->input->post('assigned_to').']. Due to duplicate user to same employee');
			}else if( strcasecmp( $res, 'already_assigned' ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! same query already assigned to ['.$this->input->post('assigned_to').'].');
				log_message('debug', 'Unable to assign query to ['.$this->input->post('assigned_to').']. Due to duplicate user to same employee');
			}
		}
		//redirect(base_url().'admin/newusers');
		redirect(base_url().'admin/'.$this->input->post('to'));
	}

	public function businessAction( $bType, $action, $formId ){
		$this->load->model('admin/Assign_model', 'assign');
		$res = $this->assign->businessAction( $bType, $action, $formId );
		if( strcasecmp( $res, 'true' ) == 0 ){
			$this->session->set_flashdata('msg', 'Business accepted successfully.');
		}else{
			$this->session->set_flashdata('msg', 'Business acceptation failed.');

		}
		redirect(base_url().'admin/seller');
	}
	
	//user re assign 
	public function ReassignUser(){
		$this->load->model('admin/Assign_model', 'assign');
		$res = $this->assign->ReassignCustomerToEmployee();
		
		//print_r($res);
		//die;
		
		if( strcasecmp( $res, 'true' ) == 0 ){
			$this->load->model('admin/Users_model', 'users');
			if( strcasecmp( $this->users->updateUserStatus( $this->input->post('user_id') ), 'true' ) == 0 ){
				$this->session->set_flashdata('msg', 'User assigned successfully.');
			}else{
				$this->session->set_flashdata('msg', 'User assignment failed.');
			}
		}else{
			if( strcasecmp( $res, 'false' ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! some thing went wrong please try again.');
				log_message('debug', 'Unable to assign user to ['.$this->input->post('assigned_to').']. Due to db insertion fail');
			}else if( strcasecmp( $res, 'duplicate' ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! same user already assigned to ['.$this->input->post('assigned_to').'].');
				log_message('debug', 'Unable to assign user to ['.$this->input->post('assigned_to').']. Due to duplicate user to same employee');
			}else if( strcasecmp( $res, 'already_assigned' ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! same user already assigned to ['.$this->input->post('assigned_to').'].');
				log_message('debug', 'Unable to assign user to ['.$this->input->post('assigned_to').']. Due to duplicate user to same employee');
			}
		}
		redirect(base_url().'admin/newuser');
		//redirect(base_url().'admin/'.$this->input->post('to'));
	}
	
	
	
	//query re assign
		public function reassignQuery($query_id){
		$this->load->model('admin/Assign_model', 'assign');
		$res = $this->assign->assignReQueryToEmployee();
		if( strcasecmp( $res, 'true' ) == 0 ){
			$this->load->model('admin/Users_model', 'users');
			if( strcasecmp( $this->users->updateQueryStatus( $this->input->post('query_id') ), 'true' ) == 0 ){
				$this->session->set_flashdata('msg', 'Query assigned successfully.');
			}else{
				$this->session->set_flashdata('msg', 'Query assignment failed.');
			}
		}else{
			if( strcasecmp( $res, 'false' ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! some thing went wrong please try again.');
				log_message('debug', 'Unable to assign query to ['.$this->input->post('assigned_to').']. Due to db insertion fail');
			}else if( strcasecmp( $res, 'duplicate' ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! same query already assigned to ['.$this->input->post('assigned_to').'].');
				log_message('debug', 'Unable to assign query to ['.$this->input->post('assigned_to').']. Due to duplicate user to same employee');
			}else if( strcasecmp( $res, 'already_assigned' ) == 0 ){
				$this->session->set_flashdata('msg', 'Oops! same query already assigned to ['.$this->input->post('assigned_to').'].');
				log_message('debug', 'Unable to assign query to ['.$this->input->post('assigned_to').']. Due to duplicate user to same employee');
			}
		}
		redirect(base_url().'admin/newquery');
		//redirect(base_url().'admin/'.$this->input->post('to'));
	}
	
}
?>