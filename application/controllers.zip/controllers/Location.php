<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Location extends CI_Controller {

	function __construct(){
		parent::__construct();
		//check_isvalidated();
        }

	public function getState(){
		$this->load->library('parser');
		$this->load->helper('html');
		$states = $this->cachemethods->getStateByCountry( $this->input->post('contid') );
		if( isset( $states ) && $states != null ){
			echo json_encode($states);
		}else{
			echo '[{"id":-1, "country_id":'.$this->input->post('contid').', "state_name":"Not Found"}]';
		}
	}


	public function getCities(){
		$this->load->library('parser');
		$this->load->helper('html');
		$cities = $this->cachemethods->getCityByStateId( $this->input->post('stid') );
		if( isset( $cities ) && $cities != null ){
			echo json_encode($cities);
		}else{
			echo '[{"id":-1, "state_id":'.$this->input->post('stid').', "city_name":"Not Found"}]';
		}
	}
}
